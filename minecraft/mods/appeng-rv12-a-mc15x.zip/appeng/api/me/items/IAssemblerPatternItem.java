package appeng.api.me.items;

/**
 * Like ILocationPatternItem, not really useful...
 */
public interface IAssemblerPatternItem
{
}
