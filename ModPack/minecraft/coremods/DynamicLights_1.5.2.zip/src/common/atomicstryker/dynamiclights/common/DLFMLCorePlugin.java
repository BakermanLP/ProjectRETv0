package atomicstryker.dynamiclights.common;

import java.util.Map;
import cpw.mods.fml.relauncher.IFMLLoadingPlugin;

public class DLFMLCorePlugin implements IFMLLoadingPlugin
{

    @Override
    public String[] getLibraryRequestClass()
    {
        return null;
    }

    @Override
    public String[] getASMTransformerClass()
    {
        return new String[] { "atomicstryker.dynamiclights.common.DLTransformer" };
    }

    @Override
    public String getModContainerClass()
    {
        return null;
    }

    @Override
    public String getSetupClass()
    {
        return null;
    }

    @Override
    public void injectData(Map<String, Object> data)
    {
    }

}
